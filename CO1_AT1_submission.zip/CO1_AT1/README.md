# CO1_AT1 – Question 1

## Question
Modify Bubble Sort so that it stops early when the list is already sorted. Implement and test the program, and analyze its time and space complexity.

## Folder Structure
```text
CO1_AT1/
├── Question_1/
│   ├── Source_Code/
│   │   └── bubble_sort.py
│   └── Report/
│       ├── Report.md
│       ├── source_code.png
│       └── output.png
└── README.md
```

## How to Run
1. Install Python 3 if it is not already installed.
2. Open a terminal in `Question_1/Source_Code/`.
3. Run:
   ```bash
   python bubble_sort.py
   ```
4. Enter integers separated by spaces.

## Example
Input:
```text
1 2 3 4 5
```
Output:
```text
Sorted list: [1, 2, 3, 4, 5]
```

## Complexity
- Best case: O(n), when the list is already sorted (one pass).
- Average case: O(n²).
- Worst case: O(n²).
- Auxiliary space: O(1), because sorting is performed in place.

def bubble_sort(arr):
    n = len(arr)

    for i in range(n - 1):
        swapped = False

        for j in range(n - 1 - i):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True

        # Stop early if no swaps occurred
        if not swapped:
            break

    return arr


numbers = list(map(int, input("Enter numbers separated by spaces: ").split()))
print("Sorted list:", bubble_sort(numbers))

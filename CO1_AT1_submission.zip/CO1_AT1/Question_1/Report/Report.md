# CO1_AT1 – Question 1 Report

## Title
Optimized Bubble Sort with Early Stopping

## Aim
To sort a list of integers using Bubble Sort and stop early when the list is already sorted.

## Problem Statement
Modify Bubble Sort by adding a flag that checks whether any swap occurred during a pass. If no swap occurs, the list is already sorted and the algorithm terminates early.

## Algorithm
1. Read the list of integers.
2. Set `swapped = False` at the start of each pass.
3. Compare adjacent elements.
4. Swap them if they are in the wrong order and set `swapped = True`.
5. If no swap occurred during the pass, stop the loop.
6. Display the sorted list.

## Source Code
The complete program is saved as `Source_Code/bubble_sort.py`.

## Test Case
**Input:** `1 2 3 4 5`  
**Expected output:** `Sorted list: [1, 2, 3, 4, 5]`

## Analysis
Let `n` be the number of elements.

| Case | Time Complexity | Explanation |
|---|---|---|
| Best | O(n) | The list is already sorted, so one pass is enough. |
| Average | O(n²) | Multiple passes and adjacent comparisons are usually required. |
| Worst | O(n²) | A reverse-ordered list requires the maximum number of passes. |

**Auxiliary space:** O(1), because the algorithm sorts the list in place and uses only a few extra variables.

## Result
The optimized Bubble Sort program sorts the input list correctly. The `swapped` flag allows it to stop after a pass with no swaps, improving the best-case time complexity to O(n).

## Documentation / Execution
Run the program using Python 3:
```bash
python bubble_sort.py
```
Enter numbers separated by spaces when prompted. The source-code and output screenshots are included in this report folder.

def add(A, B):
    n = len(A)
    return [[A[i][j] + B[i][j] for j in range(n)] for i in range(n)]

def sub(A, B):
    n = len(A)
    return [[A[i][j] - B[i][j] for j in range(n)] for i in range(n)]

def conventional(A, B):
    n = len(A)
    C = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]
    return C

def strassen(A, B, threshold=1):
    n = len(A)
    if n <= threshold:
        return conventional(A, B)
    mid = n // 2
    A11 = [row[:mid] for row in A[:mid]]
    A12 = [row[mid:] for row in A[:mid]]
    A21 = [row[:mid] for row in A[mid:]]
    A22 = [row[mid:] for row in A[mid:]]
    B11 = [row[:mid] for row in B[:mid]]
    B12 = [row[mid:] for row in B[:mid]]
    B21 = [row[:mid] for row in B[mid:]]
    B22 = [row[mid:] for row in B[mid:]]
    M1 = strassen(add(A11,A22), add(B11,B22), threshold)
    M2 = strassen(add(A21,A22), B11, threshold)
    M3 = strassen(A11, sub(B12,B22), threshold)
    M4 = strassen(A22, sub(B21,B11), threshold)
    M5 = strassen(add(A11,A12), B22, threshold)
    M6 = strassen(sub(A21,A11), add(B11,B12), threshold)
    M7 = strassen(sub(A12,A22), add(B21,B22), threshold)
    C11 = add(sub(add(M1,M4),M5),M7)
    C12 = add(M3,M5)
    C21 = add(M2,M4)
    C22 = add(sub(add(M1,M3),M2),M6)
    return ([C11[i]+C12[i] for i in range(mid)] +
            [C21[i]+C22[i] for i in range(mid)])

if __name__ == "__main__":
    A = [[1, 7], [3, 5]]
    B = [[1, 3], [7, 5]]
    result = strassen(A, B)
    print("Strassen result:", result)
    print("Conventional result:", conventional(A, B))
    assert result == [[50, 38], [38, 34]]
    assert result == conventional(A, B)
    print("Strassen verified.")
def first_occurrence(records, target):
    low, high = 0, len(records) - 1
    answer = -1
    while low <= high:
        mid = (low + high) // 2
        timestamp = records[mid][0]
        if timestamp == target:
            answer = mid
            high = mid - 1
        elif timestamp < target:
            low = mid + 1
        else:
            high = mid - 1
    return answer

if __name__ == "__main__":
    orders = [(101, "O4"), (102, "O2"), (102, "O5"),
              (103, "O6"), (105, "O1"), (105, "O3")]
    index = first_occurrence(orders, 102)
    print("First index for timestamp 102:", index)
    print("First matching order:", orders[index] if index != -1 else "Not found")
    print("Missing timestamp result:", first_occurrence(orders, 999))
    assert index == 1 and orders[index] == (102, "O2")
    assert first_occurrence(orders, 999) == -1
    print("Binary Search verified.")
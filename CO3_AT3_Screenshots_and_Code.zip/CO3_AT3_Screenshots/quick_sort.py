def median_of_three_index(a, low, high):
    mid = (low + high) // 2
    trio = [(a[low], low), (a[mid], mid), (a[high], high)]
    trio.sort(key=lambda item: item[0])
    return trio[1][1]

def partition(a, low, high):
    pivot_index = median_of_three_index(a, low, high)
    a[pivot_index], a[high] = a[high], a[pivot_index]
    pivot = a[high]
    i = low - 1
    for j in range(low, high):
        if a[j] <= pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[high] = a[high], a[i + 1]
    return i + 1

def quick_sort(a, low=0, high=None):
    if high is None:
        high = len(a) - 1
    if low < high:
        p = partition(a, low, high)
        quick_sort(a, low, p - 1)
        quick_sort(a, p + 1, high)
    return a

if __name__ == "__main__":
    scores = [42, 17, 63, 8, 55, 29]
    print("Input:", scores)
    print("Sorted:", quick_sort(scores))
    assert scores == [8, 17, 29, 42, 55, 63]
    print("Quick Sort verified.")
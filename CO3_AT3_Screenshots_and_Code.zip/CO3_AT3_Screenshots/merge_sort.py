def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i][0] <= right[j][0]:  # stable tie handling
            result.append(left[i]); i += 1
        else:
            result.append(right[j]); j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

def merge_sort(items):
    if len(items) <= 1:
        return items[:]
    mid = len(items) // 2
    return merge(merge_sort(items[:mid]), merge_sort(items[mid:]))

if __name__ == "__main__":
    orders = [(105, "O1"), (102, "O2"), (105, "O3"),
              (101, "O4"), (102, "O5"), (103, "O6")]
    print("Input:", orders)
    result = merge_sort(orders)
    print("Sorted:", result)
    assert result == [(101, "O4"), (102, "O2"), (102, "O5"),
                      (103, "O6"), (105, "O1"), (105, "O3")]
    print("Stable sorting verified.")